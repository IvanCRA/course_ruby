# frozen_string_literal: true

module CalcHelper
end

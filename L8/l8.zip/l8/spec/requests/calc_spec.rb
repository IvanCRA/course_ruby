# frozen_string_literal: true

require 'rails_helper'
# require '/app/controllers/calc_controller'
RSpec.describe 'Calcs', type: :request do
  # let!(:number) {'10'}
  # let!(:source_numbers) { '6 28 214 5 28 28 28 43 35 1 6' }
  describe 'GET /calculations' do
    it 'works! (now write some real specs)' do
      get root_path
      expect(response).to have_http_status(200)
    end
  end
  #   describe "POST /calculations" do
  #     it "works! (now write some real specs)" do
  #   #    post calculations_path, params: {calculation: {source_numbers: '6 28 14 5 28 28 6 2 6 6'}}
  #    #   post calculations_path, params: {calculation: {source_numbers: '6 56 14 5 56 56 6 8 6 6'}}
  #   #    expect(response).to be_redirect
  #       get calculations_path, params: {calculation: {source_numbers: '6 28 14 5 28 28 6 2 6 6'}}
  #       expect(view).to eq(2)
  #     end
  #   end
end

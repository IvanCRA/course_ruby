function test ()
{
    table = document.getElementById('table-body')
    table.innerHTML = "";
    count = 0;
        
        tr = document.createElement('tr');
       for (let i = 0; i < 3; i++) {
          td = document.createElement("td");
          if (i == 0) { 
            td.innerHTML = '<%= @quantity %>';
          } 
          else if(i == 1) {
            td.innerHTML = '<%= @arr[0] %>'
          } else if (i == 2) {
            td.innerHTML = '<%= @max_arr %>'           
          }
          tr.appendChild(td);
          }

          
          table.appendChild(tr)
    
}